package me.shreyeschekuru.dsa.data;

public enum Role {
    USER, ADMIN;
}
